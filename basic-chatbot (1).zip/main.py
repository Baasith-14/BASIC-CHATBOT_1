def greet_user():
    name = input("Please enter your name: ")
    print(f"Hello, {name}! Welcome to the chatbot.")
    return name

def get_response(user_input):
    
    user_input = user_input.lower()
    
    if user_input == "hello":
        return "Hi!"
    elif user_input == "how are you":
        return "I'm fine, thanks!"
    elif user_input == "bye":
        return "Goodbye!"
    else:
        return "I'm not sure how to respond to that."

def chatbot():
    user_name = greet_user()
    while True:
        user_input = input(f"{user_name}: ")
        response = get_response(user_input)
        print(f"Chatbot: {response}")
        
        if user_input.lower() == "bye":
            break

chatbot()
